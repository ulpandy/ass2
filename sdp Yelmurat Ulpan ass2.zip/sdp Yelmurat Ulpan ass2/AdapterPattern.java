interface WebDriver 
{
    public void getElement(); // This method is responsible for obtaining an element using the WebDriver.
    public void selectElement(); // This method is responsible for making a selection of an element using the WebDriver.
}

class ChromeDriver implements WebDriver 
{
    @Override
    public void getElement() 
    {
        System.out.println("Retrieving an element from ChromeDriver"); // Implementation of obtaining an element in ChromeDriver.
    }

    @Override
    public void selectElement() 
    {
        System.out.println("Selecting an element using ChromeDriver"); // Implementation of making a selection of an element in ChromeDriver.
    }
}

class IEDriver
{
    public void findElement() 
    {
        System.out.println("Locating an element using IEDriver"); // Implementation of locating an element in IEDriver.
    }

    public void clickElement()
    {
        System.out.println("Clicking on an element using IEDriver"); // Implementation of clicking on an element in IEDriver.
    }
}

class WebDriverAdapter implements WebDriver 
{
    IEDriver ieDriver;

    public WebDriverAdapter(IEDriver ieDriver) 
    {
        this.ieDriver = ieDriver;
    }

    @Override
    public void getElement() 
    {
        ieDriver.findElement(); // Adapter pattern: Maps the getElement method to IEDriver's findElement method.
    }

    @Override
    public void selectElement() 
    {
        ieDriver.clickElement(); // Adapter pattern: Maps the selectElement method to IEDriver's clickElement method.
    }
}

public class AdapterPattern
{
    public static void main(String[] args) 
    {
        ChromeDriver a = new ChromeDriver();
        a.getElement(); // Utilizing ChromeDriver to retrieve and make selections of elements.

        IEDriver e = new IEDriver();
        e.findElement(); // Utilizing IEDriver to locate an element.
        e.clickElement(); // Utilizing IEDriver to click on an element.

        WebDriver wID = new WebDriverAdapter(e);
        wID.getElement(); // Utilizing the adapted IEDriver through WebDriverAdapter to retrieve an element.
        wID.selectElement(); // Utilizing the adapted IEDriver through WebDriverAdapter to make a selection of an element.
    }
}