// An abstract TV class that has a reference to a Remote and defines abstract methods for powering the TV on and off.
abstract class TV {
    Remote remote;

    TV(Remote r) {
        this.remote = r;
    }

    abstract void on(); // This method is responsible for turning the TV on.
    abstract void off(); // This method is responsible for turning the TV off.
}

// Sony class that extends TV, associating it with a specific Remote.
class Sony extends TV {
    Remote remoteType;

    Sony(Remote r) {
        super(r);
        this.remoteType = r;
    }

    public void on() {
        System.out.print("Sony TV ON: ");
        remoteType.on(); // Calls the on method of the remote to power on the Sony TV.
    }

    public void off() {
        System.out.print("Sony TV OFF: ");
        remoteType.off(); // Calls the off method of the remote to power off the Sony TV.
    }
}

// Philips class that extends TV, associating it with a specific Remote.
class Philips extends TV {
    Remote remoteType;

    Philips(Remote r) {
        super(r);
        this remoteType = r;
    }

    public void on() {
        System.out.print("Philips TV ON: ");
        remoteType.on(); // Calls the on method of the remote to power on the Philips TV.
    }

    public void off() {
        System.out.print("Philips TV OFF: ");
        remoteType.off(); // Calls the off method of the remote to power off the Philips TV.
    }
}

// Remote interface defining methods for powering the remote on and off.
interface Remote {
    public void on(); // This method is responsible for turning the remote on.
    public void off(); // This method is responsible for turning the remote off.
}

// OldRemote class implementing the Remote interface.
class OldRemote implements Remote {
    @Override
    public void on() {
        System.out.println("ON with Old Remote"); // Implementation of powering on the old remote.
    }

    @Override
    public void off() {
        System.out.println("OFF with Old Remote"); // Implementation of powering off the old remote.
    }
}

// NewRemote class implementing the Remote interface.
class NewRemote implements Remote {
    @Override
    public void on() {
        System.out.println("ON with New Remote"); // Implementation of powering on the new remote.
    }

    @Override
    public void off() {
        System.out.println("OFF with New Remote"); // Implementation of powering off the new remote.
    }

public class BridgePattern {
    public static void main(String[] args) {
        // Creating instances of Sony and Philips TVs with both old and new remotes, demonstrating the Bridge pattern.
        TV sonyOldRemote = new Sony(new OldRemote());
        sonyOldRemote.on(); // Powering on a Sony TV using the old remote.
        sonyOldRemote.off(); // Powering off a Sony TV using the old remote.
        System.out.println();
    
        TV sonyNewRemote = new Sony(new NewRemote());
        sonyNewRemote.on(); // Powering on a Sony TV using the new remote.
        sonyNewRemote.off(); // Powering off a Sony TV using the new remote.
        System.out.println();
    
        TV philipsOldRemote = new Philips(new OldRemote());
        philipsOldRemote.on(); // Powering on a Philips TV using the old remote.
        philipsOldRemote.off(); // Powering off a Philips TV using the old remote.
        System.out.println();
    
        TV philipsNewRemote = new Philips(new NewRemote());
        philipsNewRemote.on(); // Powering on a Philips TV using the new remote.
        philipsNewRemote.off(); // Powering off a Philips TV using the new remote.
    }
}